package com.exampledemo.parsaniahardik.vcfdemonuts;

import android.content.Intent;
import android.net.Uri;
import android.os.Environment;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Calendar;

public class MainActivity extends AppCompatActivity {

    private EditText etname, etphon,etmail;
    private Button btn;
    private static final String VCF_DIRECTORY = "/vcf_demonuts";
    private File vcfFile;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etname = (EditText) findViewById(R.id.etname);
        etphon = (EditText) findViewById(R.id.etphon);
        etmail = (EditText) findViewById(R.id.etmail);
        btn = (Button) findViewById(R.id.btn);

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    // File vcfFile = new File(this.getExternalFilesDir(null), "generated.vcf");
                    File vdfdirectory = new File(
                            Environment.getExternalStorageDirectory() + VCF_DIRECTORY);
                    // have the object build the directory structure, if needed.
                    if (!vdfdirectory.exists()) {
                        vdfdirectory.mkdirs();
                    }

                    vcfFile = new File(vdfdirectory, "android_"+ Calendar.getInstance().getTimeInMillis() + ".vcf");

                    FileWriter fw = null;
                    fw = new FileWriter(vcfFile);
                    fw.write("BEGIN:VCARD\r\n");
                    fw.write("VERSION:3.0\r\n");
                    // fw.write("N:" + p.getSurname() + ";" + p.getFirstName() + "\r\n");
                    fw.write("FN:" + etname.getText().toString() + "\r\n");
                    //  fw.write("ORG:" + p.getCompanyName() + "\r\n");
                    //  fw.write("TITLE:" + p.getTitle() + "\r\n");
                    fw.write("TEL;TYPE=WORK,VOICE:" + etphon.getText().toString() + "\r\n");
                    //   fw.write("TEL;TYPE=HOME,VOICE:" + p.getHomePhone() + "\r\n");
                    //   fw.write("ADR;TYPE=WORK:;;" + p.getStreet() + ";" + p.getCity() + ";" + p.getState() + ";" + p.getPostcode() + ";" + p.getCountry() + "\r\n");
                    fw.write("EMAIL;TYPE=PREF,INTERNET:" + etmail.getText().toString() + "\r\n");
                    fw.write("END:VCARD\r\n");
                    fw.close();

                   /* Intent i = new Intent(); //this will import vcf in contact list
                    i.setAction(android.content.Intent.ACTION_VIEW);
                    i.setDataAndType(Uri.fromFile(vcfFile), "text/x-vcard");
                    startActivity(i);*/

                    Toast.makeText(MainActivity.this, "Created!", Toast.LENGTH_SHORT).show();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });

    }
}
